# **MANUALE PER L'USO DEL NATURA TOOL** 

## 1. Setup
All'interno della cartella c'è il file `TwitchConfig.json` che permette di controllare l'interazione dello strumento con la chat di twitch.

**NB**: I contatori si possono solo aggiornare via chat, questo è un esperimento per verificare l'effettivo funzionamento del connettore a twitch durante una live.

Per configurere il software, aprire il suddetto file e cambiare i campi a seconda delle proprie preferenze:
1. `channel`: il nome del proprio canale twitch (non il link, solo lo username)
1. `mods`: la lista delle persone autorizzate ad usare i comandi, elencati tra virgolette e separati da una virgola. **NB**: inserire i nomi dei mod tutti in minuscolo, perché lo strumento legge i messaggi e converte in minuscolo, nomi compresi.
1. `message rate`:velocità di processing dei messaggi in secondi. Più è alta più velocemente processiamo messaggi con il rischio di finirli e dover aspettare. Più è bassa più tempo usiamo per processare i messaggi, con conseguente aumento del delay tra comando e azione, ma con meno "sprechi" se non ci sono messaggi
1. `queue_length`: numero massimo di messaggi da processare per loop.
1. `workers`: numero massimo di thread impiegate per processare i messaggi. Più il numero è alto più si possono processare messaggi in contemporanea, con conseguente aumento del carico sulla CPU

## 2. COMANDI
Lo strumento mette a disposizione i seguenti comandi:

* `!ko+`: aumenta il contatore dei ko di 1 
* `!ko-`: decremente il contatore dei ko di 1 
* `!koset`: setta il contatore al valore scritto subito dopo. Utile per ripartire dopo una pausa, visto che lo strumento non salva nulla
* `!extra+`: aumenta il contatore degli allenatori extra affrontati di 1 
* `!extra-`: decremente il contatore degli allenatori extra affrontati di 1 
* `!extraset`: setta il contatore degli degli allenatori extra affrontati al valore scritto subito dopo
* `!skip+`: aumenta il contatore degli allenatori saltati di 1 
* `!skip-`: decremente il contatore degli allenatori saltati di 1 
* `!skipset`: setta il contatore degli allenatori saltati al valore scritto subito dopo
* `!selv+`: aumenta il contatore dei selvatici sconfitti di 1 
* `!selv-`: decremente il contatore dei selvatici sconfitti di 1 
* `!selvset`: setta il contatore dei selvatici sconfitti al valore scritto subito dopo
